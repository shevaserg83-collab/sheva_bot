# bot.py
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("🚀 Бот запущен!\nИспользуй:\n/add BTCUSDT — добавить монету\n/remove BTCUSDT — убрать\n/threshold 1.5 — установить порог\n/list — список монет")

async def add_coin(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if context.args:
        coin = context.args[0].upper()
        if not coin.endswith("USDT"):
            coin += "USDT"
        if coin not in user_settings["watchlist"]:
            user_settings["watchlist"].append(coin)
        await update.message.reply_text(f"✅ Добавлено: {coin}")
    else:
        await update.message.reply_text("Пример: /add BTCUSDT")

async def remove_coin(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if context.args:
        coin = context.args[0].upper()
        if not coin.endswith("USDT"):
            coin += "USDT"
        if coin in user_settings["watchlist"]:
            user_settings["watchlist"].remove(coin)
            await update.message.reply_text(f"❌ Удалено: {coin}")
        else:
            await update.message.reply_text("Монета не в списке")
    else:
        await update.message.reply_text("Пример: /remove BTCUSDT")

async def set_threshold(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if context.args:
        try:
            thr = float(context.args[0])
            user_settings["threshold"] = thr
            await update.message.reply_text(f"✅ Порог движения: {thr}%")
        except ValueError:
            await update.message.reply_text("Введите число, например: /threshold 2.0")
    else:
        await update.message.reply_text("Пример: /threshold 1.5")

async def list_coins(update: Update, context: ContextTypes.DEFAULT_TYPE):
    coins = "\n".join(user_settings["watchlist"]) or "Список пуст"
    await update.message.reply_text(f"🔍 Отслеживаемые монеты:\n{coins}")

# === Запуск бота ===
def main():
    application = Application.builder().token(TELEGRAM_BOT_TOKEN).build()

    # Команды
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("add", add_coin))
    application.add_handler(CommandHandler("remove", remove_coin))
    application.add_handler(CommandHandler("threshold", set_threshold))
    application.add_handler(CommandHandler("list", list_coins))

    # Запуск периодической проверки
    job_queue = application.job_queue
    job_queue.run_repeating(check_prices, interval=CHECK_INTERVAL_SECONDS)

    logger.info("Бот запущен...")
    application.run_polling()

if __name__ == "__main__":
    main()