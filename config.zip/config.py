# config.py

# === TELEGRAM ===
TELEGRAM_BOT_TOKEN = "8551977563:AAGhNpH4mHJXqODduU9oc1VckIfdxs4qBGY"
ADMIN_CHAT_ID = 674076768  # твой Telegram ID

# === COINGLASS API ===
COINGLASS_API_KEY = "f6a4ffcaf1bc42b48e9a7591bd58d5e1"

# === НАСТРОЙКИ БОТА ===
DEFAULT_THRESHOLD = 1.0        # % движения
MIN_VOLUME_USD = 1_000_000    # мин. объём в USD
CHECK_INTERVAL_SECONDS = 180  # проверка каждые N секунд
WATCHLIST = ["BTCUSDT", "ETHUSDT", "SOLUSDT"]